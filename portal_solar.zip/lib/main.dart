
import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import 'dart:async';

void main() {
  runApp(const PortalSolarApp());
}

class PortalSolarApp extends StatelessWidget {
  const PortalSolarApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Portal Solar',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primarySwatch: Colors.deepOrange,
        scaffoldBackgroundColor: Colors.black,
      ),
      home: const SplashScreen(),
    );
  }
}

// SplashScreen, HomePage, ZaratienPage, ShenandoahPage, ServiciosPage y PrivacyPage
// Aquí se puede copiar el código completo que proporcionamos antes
